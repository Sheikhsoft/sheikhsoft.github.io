migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("llxjjbbic7dgdwa")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "p6hmsw5y",
    "name": "category",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 5,
      "collectionId": "zudr8mfyo0o48vj",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("llxjjbbic7dgdwa")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "p6hmsw5y",
    "name": "category_id",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 5,
      "collectionId": "zudr8mfyo0o48vj",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
})
