migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("llxjjbbic7dgdwa")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "p6hmsw5y",
    "name": "category",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 5,
      "collectionId": "zudr8mfyo0o48vj",
      "cascadeDelete": false
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bjpidj9t",
    "name": "image",
    "type": "file",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 10,
      "maxSize": 5242880,
      "mimeTypes": [],
      "thumbs": []
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "kxnrhhet",
    "name": "price",
    "type": "relation",
    "required": true,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "9t16wb2ljlbvayd",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("llxjjbbic7dgdwa")

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "p6hmsw5y",
    "name": "category",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 5,
      "collectionId": "zudr8mfyo0o48vj",
      "cascadeDelete": false
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bjpidj9t",
    "name": "image",
    "type": "file",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 10,
      "maxSize": 5242880,
      "mimeTypes": [],
      "thumbs": []
    }
  }))

  // update
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "kxnrhhet",
    "name": "price",
    "type": "relation",
    "required": false,
    "unique": false,
    "options": {
      "maxSelect": 1,
      "collectionId": "9t16wb2ljlbvayd",
      "cascadeDelete": false
    }
  }))

  return dao.saveCollection(collection)
})
